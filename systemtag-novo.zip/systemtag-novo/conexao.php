<?php

    session_start();

    define('HOST', 'localhost');
    define('BANCO', 'hgsy4588_systemtag');
    define('USER', 'root');
    define('PASS', '');

    try {
        $pdo = new PDO('mysql:host=' . HOST . ';dbname=' . BANCO, USER, PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo "ERROR: " . $e->getMessage();
    }