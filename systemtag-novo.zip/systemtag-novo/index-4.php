<?php
  require 'conexao.php';
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from blogzine.webestica.com/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 29 Apr 2023 13:15:14 GMT -->
<head>
	<title>Blogzine - Blog and Magazine Bootstrap 5 Theme</title>
	<!-- Meta Tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="author" content="Webestica.com">
	<meta name="description" content="Bootstrap based News, Magazine and Blog Theme">

	<!-- Dark mode -->
	<script>
		const storedTheme = localStorage.getItem('theme')
 
		const getPreferredTheme = () => {
			if (storedTheme) {
				return storedTheme
			}
			return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
		}

		const setTheme = function (theme) {
			if (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches) {
				document.documentElement.setAttribute('data-bs-theme', 'dark')
			} else {
				document.documentElement.setAttribute('data-bs-theme', theme)
			}
		}

		setTheme(getPreferredTheme())

		window.addEventListener('DOMContentLoaded', () => {
		    var el = document.querySelector('.theme-icon-active');
			if(el != 'undefined' && el != null) {
				const showActiveTheme = theme => {
				const activeThemeIcon = document.querySelector('.theme-icon-active use')
				const btnToActive = document.querySelector(`[data-bs-theme-value="${theme}"]`)
				const svgOfActiveBtn = btnToActive.querySelector('.mode-switch use').getAttribute('href')

				document.querySelectorAll('[data-bs-theme-value]').forEach(element => {
					element.classList.remove('active')
				})

				btnToActive.classList.add('active')
				activeThemeIcon.setAttribute('href', svgOfActiveBtn)
			}

			window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
				if (storedTheme !== 'light' || storedTheme !== 'dark') {
					setTheme(getPreferredTheme())
				}
			})

			showActiveTheme(getPreferredTheme())

			document.querySelectorAll('[data-bs-theme-value]')
				.forEach(toggle => {
					toggle.addEventListener('click', () => {
						const theme = toggle.getAttribute('data-bs-theme-value')
						localStorage.setItem('theme', theme)
						setTheme(theme)
						showActiveTheme(theme)
					})
				})

			}
		})
		
	</script>

	<!-- Favicon -->
	<link rel="shortcut icon" href="assets/images/favicon.ico">

	<!-- Google Font -->
	<link rel="preconnect" href="https://fonts.gstatic.com/">
	<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&amp;family=Rubik:wght@400;500;700&amp;display=swap" rel="stylesheet">

	<!-- Plugins CSS -->
	<link rel="stylesheet" type="text/css" href="assets/vendor/font-awesome/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
	<link rel="stylesheet" type="text/css" href="assets/vendor/tiny-slider/tiny-slider.css">
	<link rel="stylesheet" type="text/css" href="assets/vendor/glightbox/css/glightbox.css">
	<link rel="stylesheet" type="text/css" href="assets/vendor/plyr/plyr.css">

	<!-- Theme CSS -->
	<link id="style-switch" rel="stylesheet" type="text/css" href="assets/css/style.css">

</head>

<body>

<!-- Top alert START -->
<div class="alert alert-warning py-2 m-0 bg-primary border-0 rounded-0 alert-dismissible fade show text-center overflow-hidden" role="alert">
	<!-- SVG shape START -->
	<figure class="position-absolute top-50 start-50 translate-middle">
		<svg width="1848" height="481" viewBox="0 0 1848.9 481.8" xmlns="http://www.w3.org/2000/svg">
			<path class="fill-success" d="m779.4 251c-10.3-11.5-19.9-23.8-29.4-36.1-9-11.6-18.4-22.8-27.1-34.7-15.3-21.2-30.2-45.8-54.8-53.3-10.5-3.2-21.6-3.2-30.6 2.5-7.6 4.8-13 12.6-17.3 20.9-10.8 20.6-16.1 44.7-24.6 66.7-7.9 20.2-19.4 38.6-33.8 54.3-14.7 16.2-31.7 30-50.4 41-15.9 9.4-33.4 17.2-52 19.3-18.4 2-38-2.5-56.5-6.2-22.4-4.4-45.1-9.7-67.6-10.9-9.8-0.5-19.8-0.3-29.1 2.3-9.8 2.8-18.7 8.6-26.6 15.2-17.3 14.5-30.2 34.4-43.7 52.9-12.9 17.6-26.8 34.9-45.4 45.4-19.5 11-42.6 12.1-65 6.6-52.3-13.1-93.8-56.5-127.9-101.5-8.8-11.6-17.3-23.4-25.6-35.4-0.6-0.9-1.1-1.8-1.6-2.7-1.1-2.4-0.9-2.6 0.6-1.2 1 0.9 1.9 1.9 2.7 3 35.3 47.4 71.5 98.5 123.2 123.9 22.8 11.2 48.2 17.2 71.7 12.2 23-5 40.6-21.2 55.3-39.7 24.5-30.7 46.5-75.6 87.1-83 19.5-3.5 40.7 0.1 60.6 3.7 21.2 3.9 42.3 9.1 63.6 11.7 17.8 2.3 35.8-0.1 52.2-7 20-8.1 38.4-20.2 54.8-34.6 16.2-14.1 31-30.7 41.8-50.4 11.1-20.2 17-43.7 24.9-65.7 6.1-16.9 13.8-36.2 29.3-44.5 16.1-8.6 37.3-1.9 52.3 10.6 18.7 15.6 31.2 39.2 46.7 58.2"/>
			<path class="fill-warning" d="m1157.9 344.9c9.8 7.6 18.9 15.8 28.1 24 8.6 7.7 17.6 15.2 26 23.2 14.8 14.2 29.5 30.9 51.2 34.7 9.3 1.6 18.8 0.9 26.1-3.8 6.1-3.9 10.2-9.9 13.2-16.2 7.6-15.6 10.3-33.2 15.8-49.6 5.2-15.1 13.6-29 24.7-41.3 11.4-12.6 24.8-23.6 40-32.8 12.9-7.8 27.3-14.6 43.1-17.3 15.6-2.6 32.8-0.7 49 0.7 19.6 1.7 39.4 4 58.8 3.4 8.4-0.3 17-1.1 24.8-3.6 8.2-2.7 15.4-7.4 21.6-12.7 13.7-11.6 23.1-26.7 33.3-40.9 9.6-13.5 20.2-26.9 35.3-35.6 15.8-9.2 35.6-11.6 55.2-9.1 45.7 5.8 84.8 34.3 117.6 64.4 8.7 8 17.2 16.2 25.6 24.6 2.5 3.2 1.9 3-1.2 1-34.3-32-69.7-66.9-116.5-81.9-20.5-6.5-42.7-9.2-62.4-4-19.3 5.1-33.1 17.9-44.3 32.2-18.5 23.7-33.9 57.5-68.1 65.5-16.5 3.8-34.9 2.6-52.3 1.3-18.5-1.4-37-3.7-55.4-4.2-15.5-0.5-30.7 2.5-44.2 8.5-16.5 7.2-31.3 17.1-44.3 28.5-12.8 11.2-24.1 24.1-31.9 39-7.9 15.3-11.1 32.5-16.2 48.9-3.9 12.6-9 26.9-21.6 33.9-13.1 7.3-31.9 3.8-45.7-4.1-17.2-10-29.9-26.1-44.6-38.8"/>
			<path class="fill-warning" d="m1840.8 379c-8.8 40.3-167.8 79.9-300.2 45.3-42.5-11.1-91.4-32-138.7-11.6-38.7 16.7-55 66-90.8 67.4-25.1 1-48.6-20.3-58.1-39.8-31-63.3 50.7-179.9 155.7-208.1 50.4-13.5 97.3-3.2 116.1 1.6 36.3 9.3 328.6 87.4 316 145.2z"/>
			<path class="fill-success" d="M368.3,247.3C265.6,257.2,134,226,110.9,141.5C85,47.2,272.5-9.4,355.5-30.7s182.6-31.1,240.8-18.6    C677.6-31.8,671.5,53.9,627,102C582.6,150.2,470.9,237.5,368.3,247.3z"/>
		</svg>
	</figure>
	<!-- SVG shape END -->
	<div class="position-relative">
		<p class="text-white m-0">Oferta em todos os serviços. 35% de desconto! <a href="#" class="btn btn-xs btn-dark ms-3 mb-0">Agarra agora!</a></p>
	</div>
	<!-- Close button -->
	<button type="button" class="btn-close btn-close-white opacity-9 p-3" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<!-- Top alert END -->

<!-- Offcanvas START -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasMenu">
	<div class="offcanvas-header justify-content-end">
		<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
	</div>
	<div class="offcanvas-body d-flex flex-column pt-0">
		<div>
			<img class="light-mode-item my-3" src="assets/images/logo.svg" alt="logo">
			<img class="dark-mode-item my-3" src="assets/images/logo-light.svg" alt="logo">
			<p>The next-generation blog, news, and magazine theme for you to start sharing your stories today! </p>
			<!-- Nav START -->
			<ul class="nav d-block flex-column my-4">
				<li class="nav-item h5">
					<a class="nav-link" href="index-2.html">Home</a>
				<li class="nav-item h5">
					<a class="nav-link" href="about-us.html">About</a>
				</li>
				<li class="nav-item h5">
					<a class="nav-link" href="post-grid.html">Our Journal</a>
				</li>
				<li class="nav-item h5">
					<a class="nav-link" href="contact-us.html">Contact Us</a>
				</li>
			</ul>
			<!-- Nav END -->
			<div class="bg-primary bg-opacity-10 p-4 mb-4 text-center w-100 rounded">
				<span>The Blogzine</span>
				<h3>Save on Premium Membership</h3>
				<p>Get the insights report trusted by experts around the globe. Become a Member Today!</p>
				<a href="#" class="btn btn-warning">View pricing plans</a>
			</div>
		</div>
		<div class="mt-auto pb-3">
			<!-- Address -->
			<p class="text-body mb-2 fw-bold">New York, USA (HQ)</p>
			<address class="mb-0">750 Sing Sing Rd, Horseheads, NY, 14845</address>
			<p class="mb-2">Call: <a href="#" class="text-body"><u>469-537-2410</u> (Toll-free)</a> </p>
			<a href="#" class="text-body d-block">hello@blogzine.com</a>
		</div>
	</div>
</div>
<!-- Offcanvas END -->

<!-- =======================
Header START -->
<header class="navbar-light navbar-sticky header-static">
	<div class="navbar-top d-none d-lg-block small">
		<div class="container">
			<div class="d-md-flex justify-content-between align-items-center my-2">
				<!-- Top bar left -->
				<ul class="nav">
					<li class="nav-item">
						<a class="nav-link ps-0" href="about-us.html">Sobre</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="shop-grid.html">Loja</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="signin.html">Login / Cadastre-se</a>
					</li>
				</ul>
				<!-- Top bar right -->
				<div class="d-flex align-items-center">
					<!-- Font size accessibility START -->
					<div class="btn-group me-3" role="group" aria-label="font size changer">
						<input type="radio" class="btn-check" name="fntradio" id="font-sm">
						<label class="btn btn-xs btn-outline-primary mb-0" for="font-sm">A-</label>

						<input type="radio" class="btn-check" name="fntradio" id="font-default" checked>
						<label class="btn btn-xs btn-outline-primary mb-0" for="font-default">A</label>

						<input type="radio" class="btn-check" name="fntradio" id="font-lg">
						<label class="btn btn-xs btn-outline-primary mb-0" for="font-lg">A+</label>
					</div>

					<!-- Dark mode options START -->
					<div class="nav-item dropdown mx-2">
						<!-- Switch button -->
						<button class="modeswitch" id="bd-theme" type="button" aria-expanded="false" data-bs-toggle="dropdown" data-bs-display="static">
							<svg class="theme-icon-active"><use href="#"></use></svg>
						</button>
						<!-- Dropdown items -->
						<ul class="dropdown-menu min-w-auto dropdown-menu-end" aria-labelledby="bd-theme">
							<li class="mb-1">
								<button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="light">
									<svg width="16" height="16" fill="currentColor" class="bi bi-brightness-high-fill fa-fw mode-switch me-1" viewBox="0 0 16 16">
										<path d="M12 8a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
										<use href="#"></use>
									</svg>Light
								</button>
							</li>
							<li class="mb-1">
								<button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="dark">
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-moon-stars-fill fa-fw mode-switch me-1" viewBox="0 0 16 16">
										<path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/>
										<path d="M10.794 3.148a.217.217 0 0 1 .412 0l.387 1.162c.173.518.579.924 1.097 1.097l1.162.387a.217.217 0 0 1 0 .412l-1.162.387a1.734 1.734 0 0 0-1.097 1.097l-.387 1.162a.217.217 0 0 1-.412 0l-.387-1.162A1.734 1.734 0 0 0 9.31 6.593l-1.162-.387a.217.217 0 0 1 0-.412l1.162-.387a1.734 1.734 0 0 0 1.097-1.097l.387-1.162zM13.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.156 1.156 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.156 1.156 0 0 0-.732-.732l-.774-.258a.145.145 0 0 1 0-.274l.774-.258c.346-.115.617-.386.732-.732L13.863.1z"/>
										<use href="#"></use>
									</svg>Dark
								</button>
							</li>
							<li>
								<button type="button" class="dropdown-item d-flex align-items-center active" data-bs-theme-value="auto">
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-circle-half fa-fw mode-switch me-1" viewBox="0 0 16 16">
										<path d="M8 15A7 7 0 1 0 8 1v14zm0 1A8 8 0 1 1 8 0a8 8 0 0 1 0 16z"/>
										<use href="#"></use>
									</svg>Auto
								</button>
							</li>
						</ul>
					</div>
					<!-- Dark mode options END -->

					<ul class="nav">
						<li class="nav-item">
							<a class="nav-link px-2 fs-5" href="https://www.instagram.com/systemtag/" target="_blank" rel="noopener noreferrer"><i class="fab fa-instagram-square"></i></a>
						</li>
						<li class="nav-item">
							<a class="nav-link px-2 fs-5" href="#"><i class="fab fa-linkedin"></i></a>
						</li>
						<li class="nav-item">
							<a class="nav-link px-2 fs-5" href="#"><i class="fab fa-youtube-square"></i></a>
						</li>
					</ul>
				</div>
			</div>
			<!-- Divider -->
			<div class="border-bottom border-2 border-primary opacity-1"></div>
		</div>
	</div>

	<!-- Logo Nav START -->
	<nav class="navbar navbar-expand-lg">
		<div class="container">
			<!-- Logo START -->
			<a class="navbar-brand" href="index-2.html">
				<img class="navbar-brand-item light-mode-item" src="assets/images/logo.svg" alt="logo">			
				<img class="navbar-brand-item dark-mode-item" src="assets/images/logo-light.svg" alt="logo">			
			</a>
			<!-- Logo END -->

			<!-- Responsive navbar toggler -->
			<button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
				<span class="text-body h6 d-none d-sm-inline-block">Menu</span>
				<span class="navbar-toggler-icon"></span>
			</button>

			<!-- Main navbar START -->
			<div class="collapse navbar-collapse" id="navbarCollapse">
				<ul class="navbar-nav navbar-nav-scroll mx-auto">

					<!-- Nav item 1 Demos -->
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle active" href="#" id="homeMenu" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Home</a>
						<ul class="dropdown-menu" aria-labelledby="homeMenu">
							<li> <a class="dropdown-item active" href="index-2.html">Home default</a></li>
							<li> <a class="dropdown-item" href="index-lazy.html">Home lazy load</a></li>
							<li> <a class="dropdown-item" href="index-3.html">Magazine classic</a></li>
							<li> <a class="dropdown-item" href="index-4.html">Magazine</a></li>
							<li> <a class="dropdown-item" href="index-5.html">Home cards</a></li>
							<li> <a class="dropdown-item" href="index-6.html">Blog classic</a></li>
							<li> <a class="dropdown-item" href="index-7.html">Blog Personal </a></li>
							<li> <a class="dropdown-item" href="index-8.html">Blog Vintage</a></li>
							<li> <a class="dropdown-item" href="index-9.html">Blog Tech</a></li>
							<li> <a class="dropdown-item" href="index-10.html">Blog Fashion</a></li>
							<li> <a class="dropdown-item" href="index-11.html">Blog Podcast</a></li>
							<li> <a class="dropdown-item" href="index-12.html">Home Shop </a></li>
						</ul>
					</li>

					<li class="nav-item"> <a class="nav-link" href="shop-grid.html">Loja Virtual</a></li>

					<!-- Nav item 3 Post -->
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="postMenu" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Cupons de Desconto</a>
						<ul class="dropdown-menu" aria-labelledby="postMenu">
							<!-- dropdown submenu -->
							<li> <a class="dropdown-item" href="post-list.html">Systemtag</a> </li>
							<li> <a class="dropdown-item" href="post-list.html">Essenza Perfumaria</a> </li>
							<li> <a class="dropdown-item" href="post-list.html">Magazine Luiza</a> </li>
						</ul>
					</li>

					<!-- Nav item 4 Mega menu -->
					<li class="nav-item dropdown dropdown-fullwidth">
						<a class="nav-link dropdown-toggle" href="#" id="megaMenu" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Notícias</a>
						<div class="dropdown-menu" aria-labelledby="megaMenu">
							<div class="container">
								<div class="row g-4 p-3 flex-fill">
									<?php
										$sql = $pdo->query("SELECT * FROM noticias ORDER BY id DESC LIMIT 3");
										while($ln = $sql->fetch()){
									?>
									<!-- Card item START -->
									<div class="col-sm-6 col-lg-3">
										<div class="card bg-transparent">
											<!-- Card img -->
											<img class="card-img rounded" src="<?php echo $ln["imagem"] ?>" alt="Card image">
											<div class="card-body px-0 pt-3">
												<h6 class="card-title mb-0"><a href="#" class="btn-link text-reset fw-bold"><?php echo $ln["titulo"] ?></a></h6>
												<!-- Card info -->
												<ul class="nav nav-divider align-items-center text-uppercase small mt-3">
													<li class="ist-inline-item">
													<?php
                                if($ln['categoria'] == 'TECNOLOGIA'){
                                    echo "<a style='color: #fff; 
									background-color: blue; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>TECNOLOGIA</a>";

                                }else if($ln['categoria'] == 'INOVAÇÃO'){
									echo "<a style='color: #fff; 
									background-color: blue; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>INOVAÇÃO</a>";

								}else if($ln['categoria'] == 'GAMES'){
									echo "<a style='color: #fff; 
									background-color: red; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>GAMES</a>";

								}else if($ln['categoria'] == 'SEGURANÇA'){
									echo "<a style='color: #fff; 
									background-color: yellow; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>SEGURANÇA</a>";

								}else if($ln['categoria'] == 'SOFTWARE'){
									echo "<a style='color: #fff; 
									background-color: gree; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>SOFTWARE</a>";

								}else if($ln['categoria'] == 'INTERNET'){
									echo "<a style='color: #fff; 
									background-color: black; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>INTERNET</a>";

								}else if($ln['categoria'] == "CIÊNCIA"){
									echo "<a style='color: #fff; 
									background-color: blue; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>CIÊNCIAS</a>";

								}else if($ln['categoria'] == "SÉRIE"){
									echo "<a style='color: #fff; 
									background-color: red; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>SÉRIE</a>";
									
								}else if($ln['categoria'] == "FILME"){
									echo "<a style='color: #fff; 
									background-color: red; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>FILME</a>";
								}
								else if($ln['categoria'] == "ANIME"){
									echo "<a style='color: #fff; 
									background-color: yellow; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>ANIME</a>";
								}
							
                            ?>
													</li>
												</ul>
											</div>
										</div>
									</div>
									<!-- Card item END -->
									<?php 
										} 
									?>
									<div class="col-sm-6 col-lg-3">
										<div class="card bg-transparent">
											<!-- Card img -->
											<div class="card-body px-0 pt-3">
												<!-- Card info -->
												<ul class="nav nav-divider align-items-center text-uppercase small mt-3">
													<li class="list-inline-item">Tags de tendência:</li>
													<li class="list-inline-item"><a href="#" class="btn btn-sm btn-primary-soft">TECNOLOGIA</a></li>
													<li class="list-inline-item"><a href="#" class="btn btn-sm btn-warning-soft">INOVAÇÃO</a></li>
													<li class="list-inline-item"><a href="#" class="btn btn-sm btn-success-soft">SEGURANÇA</a></li>
													<li class="list-inline-item"><a href="#" class="btn btn-sm btn-danger-soft">CIÊNCIA</a></li>
													<li class="list-inline-item"><a href="#" class="btn btn-sm btn-info-soft">FILMES</a></li>
													<li class="list-inline-item"><a href="#" class="btn btn-sm btn-primary-soft">GAMES</a></li>
													<li class="list-inline-item"><a href="#" class="btn btn-sm btn-success-soft">SÉRIES</a></li>
													<li class="list-inline-item"><a href="#" class="btn btn-sm btn-danger-soft">SOFTWARE</a></li>
												</ul>
											</div>
										</div>
									</div>
									<!-- Card item END -->
								</div> <!-- Row END -->
								<!-- Trending tags -->
								<div class="row px-3">
									<div class="col-12">
										<ul class="list-inline mt-3">
											<li class="list-inline-item" style="font-size: 30%;"><a href="#" class="btn btn-sm btn-primary-soft">VIZUALIZAR TODAS AS NOTÍCIAS</a></li>
										</ul>
									</div>
								</div> <!-- Row END -->
							</div>
						</div>
					</li>

					<!-- Nav item 5 link-->
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="postMenu" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Institucional</a>
						<ul class="dropdown-menu" aria-labelledby="postMenu">
							<!-- dropdown submenu -->
							<li> <a class="dropdown-item" href="about-us.html">Sobre nós</a> </li>
							<li> <a class="dropdown-item" href="contact-us.html">Contato</a> </li>
						</ul>
					</li>
				</ul>
			</div>
			<!-- Main navbar END -->

			<!-- Nav right START -->
			<div class="nav flex-nowrap align-items-center">
				<!-- Nav Button -->
				<div class="nav-item d-none d-md-block">
					<a href="#" class="btn btn-sm btn-danger mb-0 mx-2">Trabalhe conosco</a>
				</div>
				<!-- Nav Search -->
				<div class="nav-item dropdown dropdown-toggle-icon-none nav-search">
					<a class="nav-link dropdown-toggle" role="button" href="#" id="navSearch" data-bs-toggle="dropdown" aria-expanded="false">
						<i class="bi bi-search fs-4"> </i>
					</a>
					<div class="dropdown-menu dropdown-menu-end shadow rounded p-2" aria-labelledby="navSearch">
						<form class="input-group">
							<input class="form-control border-success" type="search" placeholder="O que deseja pesquisa?" aria-label="Search">
							<button class="btn btn-success m-0" type="submit">Pesquisar</button>
						</form>
					</div>
				</div>
				<!-- Offcanvas menu toggler -->
				<div class="nav-item">
					<a class="nav-link p-0" data-bs-toggle="offcanvas" href="#offcanvasMenu" role="button" aria-controls="offcanvasMenu">
						<i class="bi bi-text-right rtl-flip fs-2" data-bs-target="#offcanvasMenu"> </i>
					</a>
				</div>
			</div>
			<!-- Nav right END -->
		</div>
	</nav>
	<!-- Logo Nav END -->
</header>
<!-- =======================
Header END -->

<!-- **************** MAIN CONTENT START **************** -->
<main>

<!-- =======================
Latest news slider START -->
<section class="py-4 card-grid">
	<div class="container">
		<div class="row">
			<div class="col">
			<center><h3>NOSSOS PRINCIPAIS SERVIÇOS</h3></center>
				<!-- Slider START -->
				<div class="tiny-slider">
					<div class="tiny-slider-inner"
					data-autoplay="true"
					data-hoverpause="true"
					data-gutter="24"
					data-arrow="false"
					data-dots="false"
					data-items-md="2" 
					data-items-sm="2" 
					data-items-xs="1"
					data-items="3" >

						<!-- Card item START -->
						<div class="card">
							<div class="row g-3">
								<div class="col-3">
									<a href="https://wa.link/9f7jd8" target="_blank" rel="noopener noreferrer"><img class="rounded-3" src="assets/images/blog/1by1/01.jpg" alt=""></a>
								</div>
								<div class="col-9">
									<h5><a href="https://wa.link/9f7jd8" target="_blank" rel="noopener noreferrer" class="btn-link stretched-link text-reset fw-bold">Desenvolvimento de Website</a></h5>
									<!-- Card info -->
									<ul class="nav nav-divider align-items-center small">
										<li class="nav-item">
											<div class="nav-link position-relative">
												<span>Faça seu orçamento agora mesmo!</span><br>
												<span style="color: white;"><a href="https://wa.link/9f7jd8" target="_blank" rel="noopener noreferrer" class="badge bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Clique aqui para iniciar a conversa</a></span>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- Card item END -->
						<!-- Card item START -->
						<div class="card">
							<div class="row g-3">
								<div class="col-3">
									<a href="https://wa.link/1ro5jh" target="_blank" rel="noopener noreferrer"><img class="rounded-3" src="assets/images/blog/1by1/02.jpg" alt=""></a>
								</div>
								<div class="col-9">
									<h5><a href="https://wa.link/1ro5jh" target="_blank" rel="noopener noreferrer" class="btn-link stretched-link text-reset fw-bold">Desenvolvimento de Aplicativo</a></h5>
									<!-- Card info -->
									<ul class="nav nav-divider align-items-center small">
										<li class="nav-item">
											<div class="nav-link position-relative">
												<span>Faça seu orçamento agora mesmo!</span><br>
												<span style="color: white;"><a href="https://wa.link/1ro5jh" target="_blank" rel="noopener noreferrer" class="badge bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Clique aqui para iniciar a conversa</a></span>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- Card item END -->
						<!-- Card item START -->
						<div class="card">
							<div class="row g-3">
								<div class="col-3">
									<a href="https://wa.link/i0949v" target="_blank" rel="noopener noreferrer"><img class="rounded-3" src="assets/images/blog/1by1/03.jpg" alt=""></a>
								</div>
								<div class="col-9">
									<h5><a href="https://wa.link/i0949v" class="btn-link stretched-link text-reset fw-bold">Consultoria de Inovação</a></h5>
									<!-- Card info -->
									<ul class="nav nav-divider align-items-center small">
										<li class="nav-item">
										<div class="nav-link position-relative">
												<span>Faça seu orçamento agora mesmo!</span><br>
												<span style="color: white;"><a href="https://wa.link/i0949v" target="_blank" rel="noopener noreferrer" class="badge bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Clique aqui para iniciar a conversa</a></span>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- Card item END -->
						<!-- Card item START -->
						<div class="card">
							<div class="row g-3">
								<div class="col-3">
									<a href="https://wa.link/g9yjd4" target="_blank" rel="noopener noreferrer"><img class="rounded-3" src="assets/images/blog/1by1/04.jpg" alt=""></a>
								</div>
								<div class="col-9">
									<h5><a href="https://wa.link/g9yjd4" class="btn-link stretched-link text-reset fw-bold">Consultoria de Marketing</a></h5>
									<!-- Card info -->
									<ul class="nav nav-divider align-items-center small">
										<li class="nav-item">
											<div class="nav-link position-relative">
												<span>Faça seu orçamento agora mesmo!</span><br>
												<span style="color: white;"><a href="https://wa.link/g9yjd4" target="_blank" rel="noopener noreferrer" class="badge bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Clique aqui para iniciar a conversa</a></span>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- Card item END -->
						<!-- Card item START -->
						<div class="card">
							<div class="row g-3">
								<div class="col-3">
									<a href="https://wa.link/v43kga" target="_blank" rel="noopener noreferrer"><img class="rounded-3" src="assets/images/blog/1by1/04.jpg" alt=""></a>
								</div>
								<div class="col-9">
									<h5><a href="https://wa.link/v43kga" class="btn-link stretched-link text-reset fw-bold">Professor/Instrutor de TI</a></h5>
									<!-- Card info -->
									<ul class="nav nav-divider align-items-center small">
										<li class="nav-item">
											<div class="nav-link position-relative">
												<span>Faça seu orçamento agora mesmo!</span><br>
												<span style="color: white;"><a href="https://wa.link/v43kga" target="_blank" rel="noopener noreferrer" class="badge bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Clique aqui para iniciar a conversa</a></span>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- Card item END -->
					</div>
				</div>
			</div>
		</div> <!-- Row END -->
	</div>
</section>
<!-- =======================
Latest news slider END -->

<!-- =======================
Main hero START -->
<section class="py-0 card-grid">
	<div class="container">
		<div class="row">
			<!-- Slider START -->
			<div class="col-lg-7">
				<div class="tiny-slider arrow-hover arrow-blur arrow-round rounded-3">
					<div class="tiny-slider-inner"
					data-autoplay="false"
					data-hoverpause="true"
					data-gutter="0"
					data-arrow="true"
					data-dots="false"
					data-items="1">
						<!-- Slide 1 -->
						<div class="card card-overlay-bottom card-bg-scale h-400 h-lg-560 rounded-0" style="background-image:url(assets/images/blog/1by1/01.jpg); background-position: center left; background-size: cover;">
							<!-- Card Image overlay -->
							<div class="card-img-overlay d-flex flex-column p-3 p-sm-5"> 
								<!-- Card overlay Top -->
								<div class="w-100 mb-auto d-flex justify-content-end">
									<div class="text-end ms-auto">
										<!-- Card format icon -->
										<div class="icon-md bg-primary bg-opacity-10 bg-blur text-white rounded-circle" title="This post has video"><i class="fas fa-video"></i></div>
									</div>
								</div>
								<!-- Card overlay Bottom  -->
								<div class="w-100 mt-auto">
									<div class="col">
										<!-- Card category -->
										<a href="#" class="badge bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>SYSTEMTAG</a>
										<!-- Card title -->
										<h2 class="text-white display-5"><a href="https://www.instagram.com/systemtag/" target="_blank" rel="noopener noreferrer" class="btn-link text-reset stretched-link fw-normal"><b>Possibilitando progresso as entidades públicas e privadas.</b></a></h2>
										<!-- Card info -->
									</div>
								</div>
							</div>
						</div>
						<!-- Slide 2 -->
						
					</div>
				</div>
			</div>
			<!-- Slider END -->
			<div class="col-lg-5 mt-5 mt-lg-0">
			<h3>ÚLTIMAS NOTÍCIAS</h3>
				<!-- Card item START -->
				<?php
                    $sql = $pdo->query("SELECT * FROM noticias ORDER BY id DESC LIMIT 4");
                    while($ln = $sql->fetch()){
                ?>
				<div class="card mb-4">
					<div class="row g-3">
						<div class="col-4">
							<img class="rounded-3" src="<?php echo $ln["imagem"] ?>" alt="">
						</div>
						<div class="col-8">
							<?php
                                if($ln['categoria'] == 'TECNOLOGIA'){
                                    echo "<a style='color: #fff; 
									background-color: blue; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>TECNOLOGIA</a>";

                                }else if($ln['categoria'] == 'INOVAÇÃO'){
									echo "<a style='color: #fff; 
									background-color: blue; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>INOVAÇÃO</a>";

								}else if($ln['categoria'] == 'GAMES'){
									echo "<a style='color: #fff; 
									background-color: red; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>GAMES</a>";

								}else if($ln['categoria'] == 'SEGURANÇA'){
									echo "<a style='color: #fff; 
									background-color: yellow; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>SEGURANÇA</a>";

								}else if($ln['categoria'] == 'SOFTWARE'){
									echo "<a style='color: #fff; 
									background-color: gree; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>SOFTWARE</a>";

								}else if($ln['categoria'] == 'INTERNET'){
									echo "<a style='color: #fff; 
									background-color: black; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>INTERNET</a>";

								}else if($ln['categoria'] == "CIÊNCIA"){
									echo "<a style='color: #fff; 
									background-color: blue; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>CIÊNCIAS</a>";

								}else if($ln['categoria'] == "SÉRIE"){
									echo "<a style='color: #fff; 
									background-color: red; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>SÉRIE</a>";
									
								}else if($ln['categoria'] == "FILME"){
									echo "<a style='color: #fff; 
									background-color: red; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>FILME</a>";
								}
								else if($ln['categoria'] == "ANIME"){
									echo "<a style='color: #fff; 
									background-color: yellow; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>ANIME</a>";
								}
							
                            ?> <span> <?php echo $ln["data"] ?></span>
							<h5><a href="post-single-4.html" class="btn-link text-reset stretched-link fw-bold"><?php echo $ln["titulo"] ?></a></h5>
						</div>
					</div>
				</div>
				<?php 
                    } 
                ?>
				<!-- Card item END -->
				
			</div>
		</div> <!-- Row END -->
	</div>
</section>
<!-- =======================
Main hero END -->

<section class="pt-4">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Title -->
				<div class="mb-4 d-md-flex justify-content-between align-items-center">
					<h2 class="m-0"><i class="bi bi-briefcase-fill"></i> Portfólio de sites</h2>
					<u>Confira alguns projetos de desenvolvimento de website da nossa equipe.</u>
				</div>
				<div class="tiny-slider arrow-hover arrow-blur arrow-dark arrow-round">
					<div class="tiny-slider-inner"
						data-autoplay="true"
						data-hoverpause="true"
						data-gutter="24"
						data-arrow="true"
						data-dots="false"
						data-items-xl="4" 
						data-items-md="3" 
						data-items-sm="2" 
						data-items-xs="1">

						<!-- Card item START -->
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Desenvolvimento de Website</a>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Desenvolvimento de Aplicativo</a>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Consultoria de Inovação</a>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Consultoria de Marketing</a>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-light mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Professor/Instrutor de TI</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="pt-4">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Title -->
				<div class="mb-4 d-md-flex justify-content-between align-items-center">
					<h2 class="m-0"><i class="bi bi-briefcase-fill"></i> Portfólio de sistemas desktop</h2>
					<u>Confira alguns projetos de desenvolvimento de sistema desktop da nossa equipe.</u>
				</div>
				<div class="tiny-slider arrow-hover arrow-blur arrow-dark arrow-round">
					<div class="tiny-slider-inner"
						data-autoplay="true"
						data-hoverpause="true"
						data-gutter="24"
						data-arrow="true"
						data-dots="false"
						data-items-xl="4" 
						data-items-md="3" 
						data-items-sm="2" 
						data-items-xs="1">

						<!-- Card item START -->
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Desenvolvimento de Website</a>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Desenvolvimento de Aplicativo</a>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Consultoria de Inovação</a>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Consultoria de Marketing</a>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-light mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Professor/Instrutor de TI</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="pt-4">
	<div class="container">
		<div class="row">
		<div class="col-lg-12">
              <div class="heading-section">
				<center>
                <h3 style="color: white;">PRINCIPAIS PARCEIROS</h3> <br>
                  <p style="color: white;">Confira alguns de nossos parceiros de serviços/produtos, marca e de distribuição.</p>
				  </center>
				</div>
              <div class="row" style="justify-content: center;">
                <div class="col-lg-3">
                    <div class="icon">
                      <a href="http://www.multsolucoes.com.br" target="_blank" rel="noopener noreferrer"><img src="https://systemtag.com.br/assets/images/parceiros/logo%20multsolucoes.png" alt="" ></a>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="icon">
                      <a href="https://www.hostgator.com.br/" target="_blank" rel="noopener noreferrer"><img src="https://systemtag.com.br/assets/images/parceiros/logo%20hostgator.png" alt="" ></a>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="icon">
                      <a href="https://www.amazon.com.br/" target="_blank" rel="noopener noreferrer"><img src="https://systemtag.com.br/assets/images/parceiros/logo%20amazon.png" alt="" ></a>
                    </div>
                </div>
              </div>
            </div>
		</div>
	</div>
</section>


</main>
<!-- **************** MAIN CONTENT END **************** -->

<!-- =======================
Footer START -->
<footer class="bg-dark pt-5">
	<div class="container">
		<!-- About and Newsletter START -->
		<div class="row pt-3 pb-4">
			<div class="col-md-3">
				<img src="assets/images/logo-footer.svg" alt="footer logo">
			</div>
			<div class="col-md-5">
				<p class="text-muted">The next-generation blog, news, and magazine theme for you to start sharing your stories today! This Bootstrap 5 based theme is ideal for all types of sites that deliver the news.</p>
			</div>
			<div class="col-md-4">
				<!-- Form -->
				<form class="row row-cols-lg-auto g-2 align-items-center justify-content-end">
					<div class="col-12">
						<input type="email" class="form-control" placeholder="Enter your email address">
					</div>
					<div class="col-12">
						<button type="submit" class="btn btn-primary m-0">Se inscrever</button>
					</div>
					<div class="form-text mt-2">Inscrever-se concorda com a nossa 
						<a href="#" class="text-decoration-underline text-reset">Politica de Privacidade</a>
					</div>
				</form>
			</div>
		</div>
		<!-- About and Newsletter END -->

		<!-- Divider -->
		<hr>

		<!-- Widgets START -->
		<div class="row pt-5">
			<!-- Footer Widget -->
			<div class="col-md-6 col-lg-3 mb-4">
				<h5 class="mb-4 text-white">Postagem recente</h5>
				<!-- Item -->
				<?php
                    $sql = $pdo->query("SELECT * FROM noticias ORDER BY id DESC LIMIT 2");
                    while($ln = $sql->fetch()){
                ?>
				<div class="mb-4 position-relative">
					<div>
					<?php
                                if($ln['categoria'] == 'TECNOLOGIA'){
                                    echo "<a style='color: #fff; 
									background-color: blue; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>TECNOLOGIA</a>";

                                }else if($ln['categoria'] == 'INOVAÇÃO'){
									echo "<a style='color: #fff; 
									background-color: blue; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>INOVAÇÃO</a>";

								}else if($ln['categoria'] == 'GAMES'){
									echo "<a style='color: #fff; 
									background-color: red; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>GAMES</a>";

								}else if($ln['categoria'] == 'SEGURANÇA'){
									echo "<a style='color: #fff; 
									background-color: yellow; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>SEGURANÇA</a>";

								}else if($ln['categoria'] == 'SOFTWARE'){
									echo "<a style='color: #fff; 
									background-color: gree; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>SOFTWARE</a>";

								}else if($ln['categoria'] == 'INTERNET'){
									echo "<a style='color: #fff; 
									background-color: black; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>INTERNET</a>";

								}else if($ln['categoria'] == "CIÊNCIA"){
									echo "<a style='color: #fff; 
									background-color: blue; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>CIÊNCIAS</a>";

								}else if($ln['categoria'] == "SÉRIE"){
									echo "<a style='color: #fff; 
									background-color: red; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>SÉRIE</a>";
									
								}else if($ln['categoria'] == "FILME"){
									echo "<a style='color: #fff; 
									background-color: red; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>FILME</a>";
								}
								else if($ln['categoria'] == "ANIME"){
									echo "<a style='color: #fff; 
									background-color: yellow; 
									--bs-badge-padding-x: 0.65em;
									--bs-badge-padding-y: 0.35em;
									--bs-badge-font-size: 0.85em;
									--bs-badge-font-weight: 400;
									--bs-badge-color: #fff;
									--bs-badge-border-radius: 0.25rem;
									display: inline-block;
									padding: var(--bs-badge-padding-y) var(--bs-badge-padding-x);
									font-size: var(--bs-badge-font-size);
									font-weight: var(--bs-badge-font-weight);
									line-height: 1;
									color: var(--bs-badge-color);
									text-align: center;
									white-space: nowrap;
									vertical-align: baseline;
    								border-radius: var(--bs-badge-border-radius);'>ANIME</a>";
								}
							
                            ?> <span> <?php echo $ln["data"] ?></span>
					</div>
					<a href="post-single-3.html" class="btn-link text-white fw-normal"><?php echo $ln["titulo"] ?></a>
				</div>
				<?php 
                    } 
                ?>
			</div>

			<!-- Footer Widget -->
			<div class="col-md-6 col-lg-3 mb-4">
				<h5 class="mb-4 text-white">Navegação</h5>
				<div class="row">
					<div class="col-6">
						<ul class="nav flex-column text-primary-hover">
							<li class="nav-item"><a class="nav-link pt-0" href="#">Notícias</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Contato</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Startups</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Suporte</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Politica de Privacidade</a></li>
							<li class="nav-item"><a class="nav-link" href="#">Boletim informativo</a></li>
						</ul>
					</div>
				</div>
			</div>

			<!-- Footer Widget -->
			<div class="col-sm-6 col-lg-3 mb-4">
				<h5 class="mb-4 text-white">Receba atualizações regulares</h5>
				<ul class="nav flex-column text-primary-hover">
					<li class="nav-item"><a class="nav-link pt-0" href="#"><i class="fab fa-whatsapp fa-fw me-2"></i>WhatsApp</a></li>
					<li class="nav-item"><a class="nav-link" href="#"><i class="fab fa-youtube fa-fw me-2"></i>Instagram</a></li>
					<li class="nav-item"><a class="nav-link" href="#"><i class="far fa-bell fa-fw me-2"></i>Notificações do site</a></li>
					<li class="nav-item"><a class="nav-link" href="#"><i class="far fa-envelope fa-fw me-2"></i>Boletins</a></li>
					<li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-headphones-alt fa-fw me-2"></i>Podcasts</a></li>
				</ul>
			</div>

			<!-- Footer Widget -->
			<div class="col-sm-6 col-lg-3 mb-4">
				<h5 class="mb-4 text-white">Nosso aplicativo móvel</h5>
				<p class="text-muted">Baixe nosso aplicativo e receba os últimos alertas de últimas notícias e os suportes desejadas.</p>
				<div class="row g-2">
					<div class="col">
						<a href="#"><img class="w-100" src="assets/images/app-store.svg" alt="app-store"></a>
					</div>
					<div class="col">
						<a href="#"><img class="w-100" src="assets/images/google-play.svg" alt="google-play"></a>
					</div>
				</div>
			</div>
		</div>
		<!-- Widgets END -->
	</div>

	<!-- Footer copyright START -->
	<div class="bg-dark-overlay-3 mt-5">
		<div class="container">
			<div class="row align-items-center justify-content-md-between py-4">
				<div class="col-md-6">
					<!-- Copyright -->
					<div class="text-center text-md-start text-primary-hover text-muted">©2023 <a href="https://www.webestica.com/" class="text-reset btn-link" target="_blank">Systemtag</a> - Criação de Sites e Consultoria no Ceará.
					</div>
				</div>
				<div class="col-md-6 d-sm-flex align-items-center justify-content-center justify-content-md-end">
					<!-- Links -->
					<ul class="nav text-primary-hover text-center text-sm-end justify-content-center justify-content-center mt-3 mt-md-0">
						<li class="nav-item"><a class="nav-link" href="#">Termos</a></li>
						<li class="nav-item"><a class="nav-link" href="#">Privacidade</a></li>
						<li class="nav-item"><a class="nav-link pe-0" href="#">Cookies</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- Footer copyright END -->
</footer>
<!-- =======================
Footer END -->


<!-- =======================
Cookies alert START -->
<div class="alert alert-dismissible fade show bg-dark text-white position-fixed start-0 bottom-0 z-index-99 shadow p-4 ms-3 mb-3 col-9 col-md-4 col-lg-3 col-xl-2" role="alert">
Este site armazena cookies no seu computador. Para saber mais sobre os cookies que utilizamos, consulte a nossa <a class="text-white" href="#"> Política de Privacidade</a>
	<div class="mt-4">
		<button type="button" class="btn btn-success-soft btn-sm mb-0" data-bs-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">Aceitar</span>
		</button>
		<button type="button" class="btn btn-danger-soft btn-sm mb-0" data-bs-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">Recusar</span>
		</button>
	</div>
	<div class="position-absolute end-0 top-0 mt-n3 me-n3"><img class="w-100" src="assets/images/cookie.svg" alt="cookie"></div>
</div>
<!-- =======================
Cookies alert END -->

<!-- Back to top -->
<div class="back-top"><i class="bi bi-arrow-up-short"></i></div>

<!-- =======================
JS libraries, plugins and custom scripts -->

<!-- Bootstrap JS -->
<script src="assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

<!-- Vendors -->
<script src="assets/vendor/tiny-slider/tiny-slider.js"></script>
<script src="assets/vendor/sticky-js/sticky.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.js"></script>
<script src="assets/vendor/plyr/plyr.js"></script>

<!-- Template Functions -->
<script src="assets/js/functions.js"></script>

</body>

<!-- Mirrored from blogzine.webestica.com/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 29 Apr 2023 13:15:27 GMT -->
</html>